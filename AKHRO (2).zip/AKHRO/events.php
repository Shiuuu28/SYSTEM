<?php
session_start();
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>events</title>
    <link rel="stylesheet" href="main.css">
    <link rel="stylesheet" href="events.css"> 
</head>
<body>
    <div class="content">
        <h1>events</h1>
        <p>This is the Events page.</p>
        <a href="main.php">Back to Dashboard</a>
    </div>
</body>
</html>