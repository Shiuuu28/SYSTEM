<?php
session_start();
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Features</title>
    <link rel="stylesheet" href="main.css?v=<?php echo time(); ?>"type = "text/css"media="all" />
    <link rel="stylesheet" href="activities.css"> 
</head>
<body>
    <div class="content">
        <h1>Features</h1>
        <p>This is the Features page.</p>
        <a href="main.php">Back to Dashboard</a>
    </div>
</body>
</html>