<?php

session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = "admin";
    $password = "12345";

    $entered_username = $_POST['username'];
    $entered_password = $_POST['password'];

    if ($entered_username == $username && $entered_password == $password) {
        $_SESSION['loggedin'] = true;

        header("Location: main.php");
        exit;
    } else {

        header("Location: login.php?error=1");
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <link rel="stylesheet" href="main.css">
</head>

<body>
    <img src="mainlogo/leftA.png" alt="Alpha Kappa Rho" class="top-left-logo">

    <div class="header-text">
        <h1 class="title">ALPHA KAPPA RHO</h1>
        <p class="subtitle">INTERNATIONAL HUMANITARIAN SERVICE FRATERNITY AND SORORITY</p>
        <p class="council">Zamboang City Council</p>
    </div>
    <div class="container">
        <div class="login-container">
            <img src="mainlogo/right.png" alt="AKRHO Logo" class="login-logo">
            <form method="POST" action="login.php">
                <input type="text" name="username" placeholder="Email" required class="username-input">
                <input type="password" name="password" placeholder="Password" required class="password-input">
                <button type="submit" class="sidebar-button">Login</button>
            </form>
            
            <?php if (isset($_GET['error'])): ?>
                <p style="color: red;">Invalid username or password!</p>
            <?php endif; ?>
        </div>
    </div>
</body>

</html>
