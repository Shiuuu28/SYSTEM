<?php
session_start();
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <link rel="stylesheet" href="main.css?v=<?php echo time(); ?>" type="text/css" media="all" /><link rel="stylesheet" href="main.css">
    <link rel="stylesheet" href="register.css"> 
</head>

<body>
    <div class="container">
        <div class="left-section">
            <h1>ALPHA KAPPA RHO</h1>
            <h3>International Humanitarian Service Fraternity and Sorority</h3>
            <h4>Zamboanga City Council</h4>
            <div class="logos">
                <img src="mainlogo/left.png" alt="Logo 1" class="logo">
                <img src="mainlogo/right.png" alt="Logo 2" class="logo">
            </div>
        </div>

        <div class="form-container">
            <h2>Registration form</h2>
            <form>
                <input type="text" placeholder="Name">
                <input type="text" placeholder="Date survived">
                <input type="text" placeholder="Baptismal name">
                <input type="text" placeholder="Batch name">
                <input type="text" placeholder="Blood Type">
                <input type="text" placeholder="Date of birth">
                <button type="submit" class="submit-btn">Submit</button>
            </form>
            <div class="back-btn-container">
                <a href="main.php" class="back-btn">Back to Dashboard</a>
            </div>
        </div>
    </div>
</body>

</html>
